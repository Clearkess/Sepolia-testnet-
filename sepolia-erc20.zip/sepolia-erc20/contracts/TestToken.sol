// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {ERC20} from "@openzeppelin/contracts/token/ERC20/ERC20.sol";

/// @title TestToken
/// @notice A plain, honestly-named ERC-20 for testnet use. No transfer
/// restrictions, no blacklist, no owner privileges after deployment.
contract TestToken is ERC20 {
    constructor(
        string memory name_,
        string memory symbol_,
        uint256 initialSupply,
        address recipient
    ) ERC20(name_, symbol_) {
        _mint(recipient, initialSupply);
    }
}

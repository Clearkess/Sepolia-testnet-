import { network } from "hardhat";

const NAME = "Test Token";
const SYMBOL = "TST";
const SUPPLY = 1_000_000n * 10n ** 18n;

const { ethers } = await network.create();
const [deployer] = await ethers.getSigners();

console.log("Deploying from:", deployer.address);
console.log("Balance:", ethers.formatEther(await ethers.provider.getBalance(deployer.address)), "ETH");

const token = await ethers.deployContract("TestToken", [NAME, SYMBOL, SUPPLY, deployer.address]);
await token.waitForDeployment();

const address = await token.getAddress();
console.log(`${NAME} (${SYMBOL}) deployed to:`, address);
console.log("Supply:", ethers.formatUnits(await token.totalSupply(), 18));
